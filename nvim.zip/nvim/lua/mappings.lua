require "nvchad.mappings"

local map = vim.keymap.set

vim.keymap.set("i","<C-d>","<Esc>:w!<CR>")
vim.keymap.set("i","<","<><Left>")
